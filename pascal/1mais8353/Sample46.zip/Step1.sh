@echo off
Rem ***********************************************************
Rem  Kurso "Informatika" 2007/2008 m.m. pavasario (2) sem.
Rem  1-as praktinis darbas. Uzduoties Nr. 46
Rem  Darba atliko: Ivona Okunevic
Rem **********************************************************
echo 4 > data.txt
echo 0.1 2 0.3 5 >> data.txt
echo 4.5 1 2 4 >> data.txt
echo 3.9 -1 3 5 >> data.txt
echo 6.4 -2 -1.5 6 >> data.txt
echo 2 6 -3 4 >> data.txt
./ivok7013 < data.txt > result.txt